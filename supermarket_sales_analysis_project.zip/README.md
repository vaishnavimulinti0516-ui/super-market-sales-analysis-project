# 🛒 Supermarket Sales Analysis

A beginner-friendly **Data Analytics** project that analyses supermarket sales data using Python and turns raw sales records into a simple **decision dashboard** with Risk, Opportunity and Action insights.

Built as part of the **Data Analytics with AI – IBM SkillsBuild** project submission.

---

## 📌 Project Overview

Supermarkets collect thousands of invoices, but raw data alone does not help managers decide what to do. This project answers questions such as:

- How much revenue and profit is the business making?
- How are sales changing over time?
- Which product lines, cities and payment methods drive the most sales?
- When are the busiest days and hours?
- What are the risks and opportunities, and what should management do?

The analysis follows the dashboard hierarchy:

| Level | Question | What the code produces |
|---|---|---|
| 1. KPIs | What is happening? | Total sales, gross income, orders, average order value, rating |
| 2. Trends | How is it changing? | Monthly, weekday and hourly sales |
| 3. Drivers | Why? | Product line, city, payment and customer type comparison |
| 4. Risk / Opportunity | What could go wrong or grow? | Auto-generated insights in `summary.txt` |
| 5. Action | What should we do? | Recommended actions in `summary.txt` |

---

## 📂 Dataset

**Supermarket Sales** dataset from Kaggle (about 1,000 invoices from 3 branches).

Main columns: `Invoice ID`, `Branch`, `City`, `Customer type`, `Gender`, `Product line`, `Unit price`, `Quantity`, `Tax 5%`, `Total`, `Date`, `Time`, `Payment`, `cogs`, `gross income`, `Rating`.

> Download the CSV from Kaggle and save it in the project folder as **`supermarket_sales.csv`**.
> If the file is missing, the code creates a small **sample dataset** so the program can still run (for testing only).

---

## 🗂️ Project Structure

```
supermarket-sales-analysis/
│
├── supermarket_sales_analysis.py   # main code file
├── requirements.txt                # libraries needed
├── README.md                       # this file
├── supermarket_sales.csv           # dataset (download from Kaggle)
│
├── charts/                         # created when you run the code
│   ├── 1_monthly_sales.png
│   ├── 2_sales_by_product.png
│   ├── 3_sales_by_city.png
│   ├── 4_payment_method.png
│   ├── 5_sales_by_hour.png
│   ├── 6_rating_distribution.png
│   ├── 7_sales_by_weekday.png
│   ├── 8_correlation_heatmap.png
│   └── dashboard.png
│
└── summary.txt                     # KPIs + Risk / Opportunity / Action
```

---

## 🚀 How to Run the Project

**Step 1: Install dependencies**

```bash
pip install -r requirements.txt
```

**Step 2: Add the dataset**

Place `supermarket_sales.csv` in the same folder as the code file.

**Step 3: Run the analysis**

```bash
python supermarket_sales_analysis.py
```

**Step 4: View the results**

- Open the `charts/` folder to see all charts and `dashboard.png`
- Open `summary.txt` to read the KPIs and insights

---

## 🧰 Tech Stack

| Purpose | Tools |
|---|---|
| Language | Python 3 |
| Data handling | Pandas, NumPy |
| Visualisation | Matplotlib, Seaborn |

---

## 🔍 What the Code Does

1. Loads the CSV file with Pandas
2. Inspects the data (shape, types, missing values, duplicates)
3. Cleans the data and creates `Month`, `Weekday` and `Hour` columns
4. Calculates KPIs
5. Finds trends over months, weekdays and hours
6. Finds drivers by product line, city, payment method and customer type
7. Saves 8 charts and 1 combined dashboard image
8. Writes Risk, Opportunity and Action insights to `summary.txt`

---

## 📈 Key Findings

> After running the code, copy the main points from `summary.txt` here.

- Total sales: _[value]_
- Best product line: _[name]_
- Best city: _[name]_
- Peak hour: _[hour]_
- Lowest rated product line: _[name]_

---

## 🔮 Future Improvements

- Build an interactive dashboard with Streamlit or Power BI
- Predict future sales with a Linear Regression model
- Add customer segmentation

---

## 👩‍💻 Author

**Vaishnavi Mulinti**
B.Tech – Electronics and Communication Engineering
