"""
Supermarket Sales Analysis - Beginner Project
=============================================
Author : Vaishnavi Mulinti
Course : Data Analytics with AI (IBM SkillsBuild)

What this program does (step by step):
    1. Loads the supermarket sales CSV file
    2. Inspects and cleans the data
    3. Calculates KPIs (what is happening?)
    4. Finds trends (how is it changing?)
    5. Finds drivers (why is it happening?)
    6. Saves charts and a dashboard image in the "charts" folder
    7. Writes Risk / Opportunity / Action insights in "summary.txt"

How to run:
    pip install -r requirements.txt
    python supermarket_sales_analysis.py
"""

import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ---------------------------------------------------------------
# Settings
# ---------------------------------------------------------------
CSV_FILE = "supermarket_sales.csv"      # put the Kaggle CSV in the same folder
CHART_FOLDER = "charts"                 # all charts are saved here
SUMMARY_FILE = "summary.txt"            # KPIs and insights are saved here

sns.set_theme(style="whitegrid")        # clean chart style
os.makedirs(CHART_FOLDER, exist_ok=True)


# ---------------------------------------------------------------
# STEP 1: Load the data
# ---------------------------------------------------------------
def make_sample_data():
    """Creates a small sample dataset (same columns as the Kaggle file).
    This is used only if the real CSV file is not found."""
    rng = np.random.default_rng(42)
    n = 1000

    branch_city = {"A": "Yangon", "B": "Mandalay", "C": "Naypyitaw"}
    branches = rng.choice(list(branch_city.keys()), n)
    product_lines = ["Health and beauty", "Electronic accessories",
                     "Home and lifestyle", "Sports and travel",
                     "Food and beverages", "Fashion accessories"]

    unit_price = rng.uniform(10, 100, n).round(2)
    quantity = rng.integers(1, 11, n)
    cogs = unit_price * quantity
    tax = cogs * 0.05

    dates = pd.to_datetime("2019-01-01") + pd.to_timedelta(rng.integers(0, 90, n), unit="D")
    hours = rng.integers(10, 21, n)
    minutes = rng.integers(0, 60, n)

    df = pd.DataFrame({
        "Invoice ID": [f"INV-{i:04d}" for i in range(1, n + 1)],
        "Branch": branches,
        "City": [branch_city[b] for b in branches],
        "Customer type": rng.choice(["Member", "Normal"], n),
        "Gender": rng.choice(["Male", "Female"], n),
        "Product line": rng.choice(product_lines, n),
        "Unit price": unit_price,
        "Quantity": quantity,
        "Tax 5%": tax.round(4),
        "Total": (cogs + tax).round(4),
        "Date": dates.strftime("%m/%d/%Y"),
        "Time": [f"{h:02d}:{m:02d}" for h, m in zip(hours, minutes)],
        "Payment": rng.choice(["Cash", "Credit card", "Ewallet"], n),
        "cogs": cogs.round(2),
        "gross margin percentage": 4.761904762,
        "gross income": tax.round(4),
        "Rating": rng.uniform(4, 10, n).round(1),
    })
    return df


def load_data():
    """Reads the CSV file. Falls back to sample data if the file is missing."""
    for file_name in [CSV_FILE, "supermarket_sales - Sheet1.csv"]:
        if os.path.exists(file_name):
            print(f"Loaded data from: {file_name}")
            return pd.read_csv(file_name)

    print("WARNING: CSV file not found. Using SAMPLE data instead.")
    print("         Download the Kaggle dataset and save it as", CSV_FILE)
    return make_sample_data()


df = load_data()


# ---------------------------------------------------------------
# STEP 2: Inspect the data
# ---------------------------------------------------------------
print("\n----- FIRST 5 ROWS -----")
print(df.head())

print("\n----- SHAPE (rows, columns) -----")
print(df.shape)

print("\n----- COLUMN TYPES -----")
print(df.dtypes)

print("\n----- MISSING VALUES -----")
print(df.isnull().sum())

print("\n----- DUPLICATE ROWS -----")
print(df.duplicated().sum())


# ---------------------------------------------------------------
# STEP 3: Clean the data
# ---------------------------------------------------------------
rows_before = len(df)
duplicates_removed = int(df.duplicated().sum())
missing_removed = int(df.isnull().any(axis=1).sum())

df = df.drop_duplicates()       # remove duplicate rows
df = df.dropna()                # remove rows with missing values

# Convert Date text into a real date
df["Date"] = pd.to_datetime(df["Date"])

# Create helper columns for analysis
df["Month"] = df["Date"].dt.to_period("M").astype(str)       # e.g. 2019-01
df["Weekday"] = df["Date"].dt.day_name()                      # e.g. Monday
df["Hour"] = pd.to_datetime(df["Time"], format="%H:%M").dt.hour

print(f"\nRows before cleaning: {rows_before}")
print(f"Rows after cleaning : {len(df)}")


# ---------------------------------------------------------------
# STEP 4: KPIs  (Level 1 - What is happening?)
# ---------------------------------------------------------------
total_sales = df["Total"].sum()
total_income = df["gross income"].sum()
total_orders = df["Invoice ID"].nunique()
avg_order_value = total_sales / total_orders
avg_rating = df["Rating"].mean()

print("\n========== KPIs ==========")
print(f"Total Sales          : {total_sales:,.2f}")
print(f"Total Gross Income   : {total_income:,.2f}")
print(f"Number of Orders     : {total_orders}")
print(f"Average Order Value  : {avg_order_value:,.2f}")
print(f"Average Rating       : {avg_rating:.2f} / 10")


# ---------------------------------------------------------------
# STEP 5: Trends  (Level 2 - How is it changing?)
# ---------------------------------------------------------------
monthly_sales = df.groupby("Month")["Total"].sum()
monthly_growth = monthly_sales.pct_change() * 100       # month-over-month %

weekday_order = ["Monday", "Tuesday", "Wednesday", "Thursday",
                 "Friday", "Saturday", "Sunday"]
weekday_sales = df.groupby("Weekday")["Total"].sum().reindex(weekday_order)

hourly_sales = df.groupby("Hour")["Total"].sum()

print("\n----- MONTHLY SALES -----")
print(monthly_sales.round(2))
print("\n----- MONTHLY GROWTH % -----")
print(monthly_growth.round(2))


# ---------------------------------------------------------------
# STEP 6: Drivers  (Level 3 - Why?)
# ---------------------------------------------------------------
product_sales = df.groupby("Product line")["Total"].sum().sort_values()
city_sales = df.groupby("City")["Total"].sum().sort_values(ascending=False)
payment_sales = df.groupby("Payment")["Total"].sum().sort_values(ascending=False)
customer_sales = df.groupby("Customer type")["Total"].sum()
rating_by_product = df.groupby("Product line")["Rating"].mean().sort_values()

print("\n----- SALES BY PRODUCT LINE -----")
print(product_sales.round(2))
print("\n----- SALES BY CITY -----")
print(city_sales.round(2))
print("\n----- SALES BY PAYMENT METHOD -----")
print(payment_sales.round(2))


# ---------------------------------------------------------------
# STEP 7: Charts
# ---------------------------------------------------------------
def save_chart(file_name):
    """Saves the current chart and closes it."""
    plt.tight_layout()
    plt.savefig(os.path.join(CHART_FOLDER, file_name), dpi=120)
    plt.close()


# Chart 1: Monthly sales trend
plt.figure(figsize=(8, 4))
plt.plot(monthly_sales.index, monthly_sales.values, marker="o", color="#1f4fd8")
plt.title("Monthly Sales Trend")
plt.xlabel("Month")
plt.ylabel("Total Sales")
save_chart("1_monthly_sales.png")

# Chart 2: Sales by product line
plt.figure(figsize=(8, 4))
plt.barh(product_sales.index, product_sales.values, color="#7b3fe4")
plt.title("Sales by Product Line")
plt.xlabel("Total Sales")
save_chart("2_sales_by_product.png")

# Chart 3: Sales by city
plt.figure(figsize=(6, 4))
plt.bar(city_sales.index, city_sales.values, color="#e8731a")
plt.title("Sales by City")
plt.ylabel("Total Sales")
save_chart("3_sales_by_city.png")

# Chart 4: Payment methods
plt.figure(figsize=(5, 5))
plt.pie(payment_sales.values, labels=payment_sales.index, autopct="%1.1f%%")
plt.title("Sales Share by Payment Method")
save_chart("4_payment_method.png")

# Chart 5: Sales by hour of the day
plt.figure(figsize=(8, 4))
plt.plot(hourly_sales.index, hourly_sales.values, marker="o", color="#d62839")
plt.title("Sales by Hour of the Day")
plt.xlabel("Hour (24-hour clock)")
plt.ylabel("Total Sales")
save_chart("5_sales_by_hour.png")

# Chart 6: Rating distribution
plt.figure(figsize=(6, 4))
sns.histplot(df["Rating"], bins=10, color="#2a9d4a")
plt.title("Customer Rating Distribution")
plt.xlabel("Rating")
save_chart("6_rating_distribution.png")

# Chart 7: Sales by weekday
plt.figure(figsize=(8, 4))
plt.bar(weekday_sales.index, weekday_sales.values, color="#1f4fd8")
plt.title("Sales by Weekday")
plt.xticks(rotation=30)
plt.ylabel("Total Sales")
save_chart("7_sales_by_weekday.png")

# Chart 8: Correlation heatmap
plt.figure(figsize=(6, 5))
sns.heatmap(df[["Unit price", "Quantity", "Total", "Rating"]].corr(),
            annot=True, cmap="Blues")
plt.title("Correlation Heatmap")
save_chart("8_correlation_heatmap.png")

# Dashboard: 4 most important charts in one image
fig, axes = plt.subplots(2, 2, figsize=(14, 9))
fig.suptitle("Supermarket Sales Dashboard", fontsize=18, fontweight="bold")

axes[0, 0].plot(monthly_sales.index, monthly_sales.values, marker="o", color="#1f4fd8")
axes[0, 0].set_title("Monthly Sales Trend")

axes[0, 1].barh(product_sales.index, product_sales.values, color="#7b3fe4")
axes[0, 1].set_title("Sales by Product Line")

axes[1, 0].bar(city_sales.index, city_sales.values, color="#e8731a")
axes[1, 0].set_title("Sales by City")

axes[1, 1].plot(hourly_sales.index, hourly_sales.values, marker="o", color="#d62839")
axes[1, 1].set_title("Sales by Hour")

fig.text(0.5, 0.01,
         f"Total Sales: {total_sales:,.0f}   |   Gross Income: {total_income:,.0f}   |   "
         f"Orders: {total_orders}   |   Avg Order: {avg_order_value:,.2f}   |   "
         f"Avg Rating: {avg_rating:.2f}",
         ha="center", fontsize=11)
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.savefig(os.path.join(CHART_FOLDER, "dashboard.png"), dpi=120)
plt.close()

print(f"\nCharts saved in the '{CHART_FOLDER}' folder.")


# ---------------------------------------------------------------
# STEP 8: Insights  (Risk, Opportunity, Action)
# ---------------------------------------------------------------
best_product = product_sales.idxmax()
weakest_product = product_sales.idxmin()
best_city = city_sales.idxmax()
top_payment = payment_sales.idxmax()
best_customer_type = customer_sales.idxmax()
peak_hour = hourly_sales.idxmax()
busiest_day = weekday_sales.idxmax()
best_month = monthly_sales.idxmax()
lowest_rated_product = rating_by_product.idxmin()

lines = [
    "SUPERMARKET SALES ANALYSIS - SUMMARY",
    "=" * 40,
    "",
    "DATA CLEANING",
    f"Rows x Columns (after cleaning) : {df.shape[0]} x {df.shape[1]}",
    f"Duplicate rows removed          : {duplicates_removed}",
    f"Rows with missing values removed: {missing_removed}",
    "",
    "KPIs",
    f"Total Sales         : {total_sales:,.2f}",
    f"Total Gross Income  : {total_income:,.2f}",
    f"Number of Orders    : {total_orders}",
    f"Average Order Value : {avg_order_value:,.2f}",
    f"Average Rating      : {avg_rating:.2f} / 10",
    "",
    "TRENDS",
    "Monthly sales:",
]
for month, value in monthly_sales.items():
    lines.append(f"  {month}: {value:,.2f}")
lines += [
    f"Best month  : {best_month}",
    f"Busiest day : {busiest_day}",
    f"Peak hour   : {peak_hour}:00",
    "",
    "DRIVERS",
    f"Best product line    : {best_product} ({product_sales.max():,.2f})",
    f"Weakest product line : {weakest_product} ({product_sales.min():,.2f})",
    f"Best city            : {best_city} ({city_sales.max():,.2f})",
    f"Top payment method   : {top_payment}",
    f"Top customer type    : {best_customer_type}",
    f"Lowest rated product : {lowest_rated_product} ({rating_by_product.min():.2f})",
    "",
    "RISK - What could hurt the business?",
    f"  - Weak sales in '{weakest_product}'.",
    f"  - Low customer rating in '{lowest_rated_product}'.",
    "",
    "OPPORTUNITY - Where could the business grow?",
    f"  - '{best_product}' and the city '{best_city}' are the strongest performers.",
    f"  - Sales peak at {peak_hour}:00 and on {busiest_day}s - ideal for promotions.",
    "",
    "ACTION - What should management do?",
    f"  - Run offers or bundles on '{weakest_product}'.",
    f"  - Collect feedback and improve quality in '{lowest_rated_product}'.",
    f"  - Keep enough staff and stock around {peak_hour}:00 and on {busiest_day}s.",
    "  - Encourage Normal customers to become Members.",
]

with open(SUMMARY_FILE, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print(f"Summary saved in '{SUMMARY_FILE}'.")
print("\nDone! Project analysis completed successfully.")
